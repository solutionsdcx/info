# SolutionsDCX Website

Static HTML website for GitHub Pages deployment.

Upload all files and enable GitHub Pages.